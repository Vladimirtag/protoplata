"""
WSGI config for proto_project project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/2.2/howto/deployment/wsgi/
"""

import os
import sys

from django.core.wsgi import get_wsgi_application
sys.path.append('/home/v54080/public_html/django/proto_project')

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'proto_project.settings')

application = get_wsgi_application()
